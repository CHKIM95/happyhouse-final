<template>
  <div>
    <h1>하이</h1>
  </div>
</template>

<script>
export default {
  name: 'QnA',
};
</script>
