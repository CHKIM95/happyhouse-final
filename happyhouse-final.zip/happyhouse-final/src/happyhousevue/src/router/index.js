import Vue from 'vue';
import VueRouter from 'vue-router';
import QnA from '../views/QnABoard.vue';
import Notice from '../views/NoticeBoard.vue';
import Login from '../views/Login.vue';
import Me from '../views/Me.vue';
import Join from '../views/Join.vue';
import store from '../store';
import Main from '../views/Main.vue';
import HouseData from '../views/HouseData.vue';

Vue.use(VueRouter);

// https://router.vuejs.org/kr/guide/advanced/navigation-guards.html
const requireAuth = () => (to, from, next) => {
  const nextRoute = to.path;

  if (store.getters.getAccessToken) {
    return next();
  } else next('/happyhouse/login' + nextRoute);
};

const routes = [
  {
    path: '/',
    name: 'Main',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Main,
  },

  {
    path: '/happyhouse/houseData',
    name: 'HouseData',
    component: HouseData,
  },

  {
    path: '/happyhouse/qna',
    name: 'QnA',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: QnA,
  },
  {
    path: 'happyhouse/notice',
    name: 'notice',
    component: Notice,
  },
  {
    path: '/happyhouse/login',
    name: 'Login',
    component: Login,
  },
  {
    path: '/happyhouse/login/:nextRoute',
    name: 'LoginNextRoute',
    component: Login,
  },
  {
    path: '/happyhouse/join',
    name: 'Join',
    component: Join,
  },
  {
    path: '/happyhouse/me',
    name: 'Me',
    component: Me,
    beforeEnter: requireAuth(),
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
